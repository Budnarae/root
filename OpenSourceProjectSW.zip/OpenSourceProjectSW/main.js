var http = require('http');
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var template = require('./lib/template.js');

var app = http.createServer(function(request,response){
    
    
    var _url = request.url;
    var queryData = url.parse(_url, true).query;
    var pathname = url.parse(_url, true).pathname;


    //메인 페이지에 있을 때
    if(pathname === '/'){
      if(queryData.id === undefined){
        fs.readdir('./data', function(error, filelist){
          //data 폴더 안의 파일들을 list화
          var list = template.list(filelist);
          //화면에 출력할 html 파일 생성
          var html = template.HTML(list,
            `<div style="text-align: center"><a href="/create">create</a></div>`
          );
          response.writeHead(200);
          response.end(html);
        });
      }
       
      
      //url로 별도의 html 파일을 만들지 않더라도 동적으로 반응
      else {
        fs.readdir('./data', function(error, filelist){
          fs.readFile(`data/${queryData.id}`, 'utf8', function(err, description){
            var title = queryData.id;
            var list = template.list(filelist);
            description = description.replaceAll("\r\n", "<BR>");
            var html = template.HTML(`
                <h3>${title}</h3>
                <div id = "des">${description}</div>`,
              ` <div style="text-align: center">
                    <a href="/create">create</a>
                    <a href="/update?id=${title}">update</a>
                    <form action="delete_process" method="post" style="display: inline;">
                    <input type="hidden" name="id" value="${title}">
                    <input type="submit" value="delete" style="background-color:transparent;  border:0px transparent solid; font-size:16px; padding:0px">
                    </form>
                </div>`
            );
            response.writeHead(200);
            response.end(html);
          });
        });
      }
    } 
    

    //html파일을 분석하다 링크를 만나면 서버로부터 css 파일을 참조할 것
    else if (pathname === "/style.css"){
        fs.readFile("./style.css", 'utf8', function(err, data){
            response.writeHead(200);
            response.write(data);
            response.end();
        })
    }


    //새로운 포스트 작성
    else if(pathname === '/create'){
      fs.readdir('./data', function(error, filelist){
        var html = template.HTML(`
        <div style="margin: auto; width: 700px;">
          <form action="/create_process" method="post">
            <p><input type="text" name="title" placeholder="title" size="100"></p>
            <p>
              <textarea name="description" placeholder="description" rows="25" cols="95"></textarea>
            </p>
            <p>
              <input type="submit" value="submit">
            </p>
          </form>
        </div>
        `, `<div style="text-align: center"><a href="/">cancel</a></div>`);
        response.writeHead(200);
        response.end(html);
      });


    //작성한 포스트를 data 폴더에 저장  
    } else if(pathname === '/create_process'){
      var body = '';
      request.on('data', function(data){
          body = body + data;
      });
      request.on('end', function(){
          var post = qs.parse(body);
          var title = post.title;
          var description = post.description;
          fs.writeFile(`data/${title}`, description, 'utf8', function(err){
            response.writeHead(302, {Location: encodeURI(`/?id=${title}`)});
            response.end();
          })
      });
    } 
    
    
    //기존의 포스트 수정
    else if(pathname === '/update'){
      fs.readdir('./data', function(error, filelist){
        fs.readFile(`data/${queryData.id}`, 'utf8', function(err, description){
          var title = queryData.id;
          var html = template.HTML(`<a href="/create">create</a> <a href="/update?id=${title}">update</a>`,
            `
            <div style="margin: auto; width: 700px;">
                <form action="/update_process" method="post">
                <input type="hidden" name="id" value="${title}">
                <p><input type="text" name="title" placeholder="title" value="${title}" size="100"></p>
                <p>
                    <textarea name="description" placeholder="description" rows="25" cols="95">${description}</textarea>
                </p>
                <p>
                    <input type="submit">
                </p>
                </form>
            </div>
            `
          );
          response.writeHead(200);
          response.end(html);
        });
      });
    } 
    
    
    //업데이트 사항을 반영
    else if(pathname === '/update_process'){
      var body = '';
      request.on('data', function(data){
          body = body + data;
      });
      request.on('end', function(){
          var post = qs.parse(body);
          var id = post.id;
          var title = post.title;
          var description = post.description;
          description = description.replaceAll("\r\n", "<BR>");
          fs.rename(`data/${id}`, `data/${title}`, function(error){
            fs.writeFile(`data/${title}`, description, 'utf8', function(err){
              response.writeHead(302, {Location: encodeURI(`/?id=${title}`)});
              response.end();
            })
          });
      });
    } 
    
    
    //포스트 삭제
    else if(pathname === '/delete_process'){
      var body = '';
      request.on('data', function(data){
          body = body + data;
      });
      request.on('end', function(){
          var post = qs.parse(body);
          var id = post.id;
          fs.unlink(`data/${id}`, function(error){
            response.writeHead(302, {Location: `/`});
            response.end();
          })
      });
    } else {
      response.writeHead(404);
      response.end('Not found');
    }
});
app.listen(3000);